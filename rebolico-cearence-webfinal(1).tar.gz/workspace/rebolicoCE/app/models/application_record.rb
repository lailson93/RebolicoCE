class ApplicationRecord < ActiveRecord::Base
  self.abstract_class = true
  
#   attr_readonly :user_id
  
  
end
